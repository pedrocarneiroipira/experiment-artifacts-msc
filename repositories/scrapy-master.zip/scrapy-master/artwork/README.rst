==============
Scrapy artwork
==============

This folder contains the Scrapy artwork resources such as logos and fonts.

scrapy-logo.jpg
---------------

The main Scrapy logo, in JPEG format.

qlassik.zip
-----------

The font used for the Scrapy logo. Homepage: https://www.dafont.com/qlassik.font

scrapy-blog.logo.xcf
--------------------

The logo used in the Scrapy blog, in Gimp format.
