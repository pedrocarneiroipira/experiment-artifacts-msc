# Tools

These are scripts used in the development of Rich, and aren't for general use. But feel free to look around.

Some ~~strikethrough~~ text.
