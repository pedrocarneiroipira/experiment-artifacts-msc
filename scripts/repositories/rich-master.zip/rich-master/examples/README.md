# Examples

This directory contains various demonstrations various Rich features. To run them, make sure Rich is installed, then run the example you want with `python example.py` on the command line. For example, `python justify.py`.

Be sure to check the source!
