rich.syntax
===========

.. automodule:: rich.syntax
    :members: Syntax
