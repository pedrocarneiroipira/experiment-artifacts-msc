rich.table
==========

.. automodule:: rich.table
    :members:
