rich.console
============

.. automodule:: rich.console
    :members:
