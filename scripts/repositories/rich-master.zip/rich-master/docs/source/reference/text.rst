rich.text
=========

.. automodule:: rich.text
    :members: Text, TextType

