rich.bar
========

.. automodule:: rich.bar
    :members:


