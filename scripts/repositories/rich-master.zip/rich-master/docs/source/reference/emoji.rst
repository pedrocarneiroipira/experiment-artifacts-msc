rich.emoji
==========

.. automodule:: rich.emoji
    :members: Emoji

