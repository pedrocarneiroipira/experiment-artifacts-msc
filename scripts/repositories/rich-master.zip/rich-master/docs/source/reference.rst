Reference
=========

.. toctree::
   :maxdepth: 3

   reference/align.rst
   reference/bar.rst
   reference/color.rst
   reference/columns.rst
   reference/console.rst
   reference/emoji.rst
   reference/highlighter.rst
   reference/init.rst
   reference/json.rst
   reference/layout.rst
   reference/live.rst
   reference/logging.rst
   reference/markdown.rst
   reference/markup.rst
   reference/measure.rst
   reference/padding.rst
   reference/panel.rst
   reference/pretty.rst
   reference/progress_bar.rst
   reference/progress.rst
   reference/prompt.rst
   reference/protocol.rst
   reference/rule.rst
   reference/segment.rst
   reference/spinner.rst
   reference/status.rst
   reference/style.rst
   reference/styled.rst
   reference/syntax.rst
   reference/table.rst
   reference/text.rst
   reference/theme.rst
   reference/traceback.rst
   reference/tree.rst
   reference/abc.rst
