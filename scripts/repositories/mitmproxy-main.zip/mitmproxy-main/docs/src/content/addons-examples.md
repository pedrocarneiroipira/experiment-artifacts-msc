---
title: "Examples"
menu:
    addons:
        weight: 6
---

{{< readfile file="/generated/examples.html" markdown="true" >}}
