
---
title: "mitmproxy.certs"
url: "api/mitmproxy/certs.html"

menu:
    addons:
        parent: 'Event Hooks & API'
---

{{< readfile file="/generated/api/mitmproxy/certs.html" >}}
