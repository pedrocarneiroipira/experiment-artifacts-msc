
---
title: "mitmproxy.coretypes.multidict"
url: "api/mitmproxy/coretypes/multidict.html"

menu:
    addons:
        parent: 'Event Hooks & API'
---

{{< readfile file="/generated/api/mitmproxy/coretypes/multidict.html" >}}
