
---
title: "mitmproxy.addonmanager"
url: "api/mitmproxy/addonmanager.html"

menu:
    addons:
        parent: 'Event Hooks & API'
---

{{< readfile file="/generated/api/mitmproxy/addonmanager.html" >}}
