
---
title: "mitmproxy.proxy.mode_specs"
url: "api/mitmproxy/proxy/mode_specs.html"

menu:
    addons:
        parent: 'Event Hooks & API'
---

{{< readfile file="/generated/api/mitmproxy/proxy/mode_specs.html" >}}
