
---
title: "mitmproxy.proxy.context"
url: "api/mitmproxy/proxy/context.html"

menu:
    addons:
        parent: 'Event Hooks & API'
---

{{< readfile file="/generated/api/mitmproxy/proxy/context.html" >}}
