
---
title: "mitmproxy.dns"
url: "api/mitmproxy/dns.html"

menu:
    addons:
        parent: 'Event Hooks & API'
---

{{< readfile file="/generated/api/mitmproxy/dns.html" >}}
