
---
title: "mitmproxy.connection"
url: "api/mitmproxy/connection.html"

menu:
    addons:
        parent: 'Event Hooks & API'
---

{{< readfile file="/generated/api/mitmproxy/connection.html" >}}
