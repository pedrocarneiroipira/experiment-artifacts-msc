
---
title: "mitmproxy.websocket"
url: "api/mitmproxy/websocket.html"

menu:
    addons:
        parent: 'Event Hooks & API'
---

{{< readfile file="/generated/api/mitmproxy/websocket.html" >}}
