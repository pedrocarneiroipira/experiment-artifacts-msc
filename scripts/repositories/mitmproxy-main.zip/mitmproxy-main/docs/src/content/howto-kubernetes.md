---
title: "Kubernetes Services"
menu:
    howto:
        weight: 1
---

# Kubernetes Services

The [github.com/soluble-ai/kubetap](https://github.com/soluble-ai/kubetap) project
provides a kubectl plugin for easily deploying mitmproxy to proxy Kubernetes Services.

For usage and documentation, please refer to the [kubetap project site](https://soluble-ai.github.io/kubetap/).
