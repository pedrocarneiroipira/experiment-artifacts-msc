# Kaitai Struct Formats

Most of the formats here are vendored from https://github.com/kaitai-io/kaitai_struct_formats/.
