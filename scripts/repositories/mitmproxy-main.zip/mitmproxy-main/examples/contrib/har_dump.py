"""
This addon is now part of mitmproxy! See mitmproxy/addons/savehar.py.
"""
