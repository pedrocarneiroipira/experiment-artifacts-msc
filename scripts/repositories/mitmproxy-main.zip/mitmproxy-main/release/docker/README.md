# Build Instructions

 1. Copy `mitmproxy-$VERSION-py3-none-any.whl` into this directory.  
    You can get the latest public release at https://mitmproxy.org/downloads/.
 2. Run `docker build .`.
