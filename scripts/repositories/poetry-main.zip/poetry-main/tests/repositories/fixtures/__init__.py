from __future__ import annotations


pytest_plugins = [
    "tests.repositories.fixtures.distribution_hashes",
    "tests.repositories.fixtures.legacy",
    "tests.repositories.fixtures.pypi",
    "tests.repositories.fixtures.python_hosted",
]
