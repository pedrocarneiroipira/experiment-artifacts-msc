# Apprendre

Voici les sections introductives et les tutoriels pour apprendre **FastAPI**.

Vous pouvez considérer ceci comme un **manuel**, un **cours**, la **méthode officielle** et recommandée pour appréhender FastAPI. 😎
