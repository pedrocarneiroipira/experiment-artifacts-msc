# Acerca de

Acerca de FastAPI, su diseño, inspiración y más. 🤓
