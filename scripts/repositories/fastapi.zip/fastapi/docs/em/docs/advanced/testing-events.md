# 🔬 🎉: 🕴 - 🤫

🕐❔ 👆 💪 👆 🎉 🐕‍🦺 (`startup` &amp; `shutdown`) 🏃 👆 💯, 👆 💪 ⚙️ `TestClient` ⏮️ `with` 📄:

```Python hl_lines="9-12  20-24"
{!../../../docs_src/app_testing/tutorial003.py!}
```
