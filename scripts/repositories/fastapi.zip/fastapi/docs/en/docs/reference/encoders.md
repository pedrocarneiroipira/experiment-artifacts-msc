# Encoders - `jsonable_encoder`

::: fastapi.encoders.jsonable_encoder
