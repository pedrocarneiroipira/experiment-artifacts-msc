from .base import sql_base


class Table(sql_base):
    pass
