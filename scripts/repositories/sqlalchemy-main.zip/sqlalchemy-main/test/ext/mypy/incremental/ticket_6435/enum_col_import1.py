import enum


class StrEnum(enum.Enum):
    one = "one"
    two = "two"


class IntEnum(enum.Enum):
    one = 1
    two = 2
